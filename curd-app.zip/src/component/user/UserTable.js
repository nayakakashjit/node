import React, { Component } from 'react';
import "./UserTable.css"

class UserTable extends Component {

    constructor(props) {
        super(props);
        
    }
    

    render() {
        return (
            <div>
            <table id="customers">
              <tr>
                <th>Id</th>
                <th>Username</th>
                <th>Email</th>
                <th>Password</th>
              </tr>
              <tr>
                <td>{this.props.userData.id}</td>
                <td>{this.props.userData.username}</td>
                <td>{this.props.userData.email}</td>
                <td>{this.props.userData.password}</td>
              </tr>
            </table>
            </div>
        );
    }
}

export default UserTable;