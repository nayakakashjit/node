import React, { Component } from 'react';
import "./App.css";
import UserTable from './component/user/UserTable';

class App extends Component {
  users = [
    { id: 1, username: 'Akash', email: 'akash.outllok.com', password: 'akash123' },
    { id: 2, username: 'Santanu', email: 'santanu.outllok.com', password: 'santanu123'},
    { id: 3, username: 'Deepak', email: 'deepak.outllok.com', password: 'deepak123' },
  ]
  render() {
    return (
      <div>
          <div class="container-fluid">
          <div class="row">
          <div class="col-md-1"></div>
            <div class="col-md-6">
            <h2>View user</h2>
              {
                   this.users.map((item)=> (
                    <UserTable userData = {item} /> 
                   ))
              }
               
            </div>
            <div class="col-md-4">
              <form>
                <h2>Add user</h2>
                <div class="input-container">
                  <i class="fa fa-user icon"></i>
                  <input class="input-field" type="text" placeholder="Username" name="usrnm" />
                </div>
  
                <div class="input-container">
                  <i class="fa fa-envelope icon"></i>
                  <input class="input-field" type="text" placeholder="Email" name="email" />
                </div>
                
                <div class="input-container">
                  <i class="fa fa-key icon"></i>
                  <input class="input-field" type="password" placeholder="Password" name="psw" />
                </div>
  
                <button type="submit" class="btn">Register</button>
              </form>
            </div>
            <div class="col-md-1"></div>
          </div>
          </div>
      </div>
    );
  }
}

export default App;