import React from "react";
import "./App.css";
import Nav from "./cpmponets/nav/nav";
import Body from "./cpmponets/body/body";
import Footer from "./cpmponets/footer/footer";


function App() {
  return (
    <div>
      <Nav/>
      <Body/>
      <Footer/>
    </div>
  );
}

export default App;
