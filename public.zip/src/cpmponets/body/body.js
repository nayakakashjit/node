import React, { Component } from 'react';
import "../body/body.css";


class body extends Component {
    render() {
        return (
            <div>
                <div class="wrapper">
                    <div class="container">
                    <div class="col-left">
                        <div class="login-text">
                            <h2>Welcome</h2>
                            <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget eros dapibus, ultricies tellus vitae, consectetur tortor. Etiam rutrum placerat
                            </p>
                            <a class="btn" href="">Read More</a>
                        </div>
                        </div>
                        <div class="col-right">
      <div class="login-form">
        <h2>Login</h2>
        <form>
          <p>
            <input type="text" placeholder="Username" required></input>
          </p>
          <p>
            <input type="password" placeholder="Password" required></input>
          </p>
          <p>
            <input class="btn" type="submit" value="Sing In" />
          </p>
          <p>
            <a href="">Forget password?</a>
            <a href="">Create an account.</a>
          </p>
        </form>
      </div>
    </div>
  </div>
                    </div>
                </div>
        );
    }
}

export default body;