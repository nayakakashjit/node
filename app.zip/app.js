var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

Genre = require('./models/genere')

// Connect To Mongoose
mongoose.connect('mongodb+srv://nodeapi:nodeapi123@nodeapi-fxsm5.mongodb.net/test?retryWrites=true&w=majority')
var db = mongoose.connection;

app.get('/', (req, res) => {
    res.send("Hi Akash")
})

app.get('/api/geners', (req, res) => {
    Genre.getGenres((err, geners) => {
        if (err) {
            throw err
        }
        res.json(geners)
    })
})

app.listen(3000)
console.log("Running on port no 3000");