var mongoose = require('mongoose');

// Genre Schema

var genereSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    create_date: {
        type: Date,
        defult: Date.now
    }
});

var Genre = module.exports = mongoose.module('Genre', genereSchema);
var Genre = module.exports = mongoose.module()

//Get Genres

module.exports.getGenres = function(callback) {
    Genre.find(callback)
}